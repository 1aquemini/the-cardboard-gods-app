# Card Ledger

Single-file trading card inventory app (Magic / Pokemon / Yu-Gi-Oh). No
backend, no database, no build step, no account, no payment — ever. It's
`index.html` plus a manifest and two icon files.

## Get it on GitHub (free hosting, no domain)

1. Go to github.com → **New repository**. Name it whatever you want (e.g.
   `card-ledger`). Public repo — GitHub Pages hosting is free either way,
   but a **public** repo is required for Pages to publish on the free plan.
   Private repos only get free Pages on paid GitHub plans.
   → If you'd rather your collection + values not be publicly viewable by
   anyone with the link, skip Pages entirely and use the "right now, no
   GitHub" method below instead — that never leaves your device.
2. Upload the contents of this folder (not the folder itself — `index.html`,
   `manifest.json`, `icons/`, `data/` should sit at the repo root) via
   **Add file → Upload files**, drag them in, commit.
3. Repo → **Settings → Pages** → under "Build and deployment," Source =
   **Deploy from a branch** → Branch = **main**, folder = **/ (root)** →
   **Save**.
4. Wait about a minute. Your app is now live, free, forever, at:
   `https://<your-username>.github.io/<repo-name>/`

No domain purchase, no App Store, no card on file — the `.github.io` address
is included free with any GitHub account.

## Put it on your iPhone

**Option A — from the GitHub Pages link above (recommended, easiest to update later):**
1. Open the `https://<your-username>.github.io/<repo-name>/` link in **Safari** on the iPhone (must be Safari, not Chrome, for this step).
2. Tap the **Share** icon → **Add to Home Screen** → **Add**.
3. A "Card Ledger" icon appears on your home screen. Tapping it opens the app full-screen, no browser bar — it behaves like an installed app.

**Option B — right now, before touching GitHub at all:**
1. Get `index.html` onto the phone any free way: AirDrop it from a Mac, email it to yourself, or drop it in iCloud Drive/Files from a computer.
2. On the iPhone, open the **Files** app, tap the file — it opens in Safari.
3. Share icon → **Add to Home Screen**. Same result as Option A, just pointed at the local file instead of a live link. Nothing to install, nothing to buy.

Either way this is **not** an App Store app and doesn't touch Apple's
Developer Program (that costs $99/year and isn't necessary for what you're
after — this sidesteps it entirely).

## Use it on a computer

Double-click `index.html` — it opens in your default browser and runs. Or
just visit the GitHub Pages URL once it's live. Nothing to install.

## Saving your data

The app now auto-saves to the browser's local storage on whichever
device/browser you're using — add, edit, or delete a card and it's
remembered next time you open it there, no manual step. The **Export CSV**
button is still there for two reasons worth keeping: it's the only way to
move your collection between devices (e.g. computer → iPhone), and it's a
real backup file on disk in case a browser ever clears its storage. Export
occasionally; import to restore or transfer.

## What's in `data/`

Not read by the app at runtime — the for-sale listings are already baked
into `index.html`. These are here as reference/backup only:

- `ygo_for_sale_inventory.csv` — the 83 current for-sale listings.
- `legacy/` — your original 8 Yu-Gi-Oh category files (Water, Dark, Spell,
  Fire, Trap, Wind, Earth, Light), trimmed down to their real rows. The
  originals each carried Excel's blank-row padding out to 1,048,576 rows
  from a formula that had been dragged down the full sheet; only the actual
  card rows are kept here (711 total across all eight — Water 83, Dark 117,
  Spell 225, Fire 76, Trap 14, Wind 87, Earth 11, Light 98).
