import os
import glob
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.dialects.postgresql import insert

RAW_DATA_DIR = '../../data/raw/'
DB_CONNECTION_STRING = 'postgresql://username:password@hostname:port/database_name' # SEE CLOSURE WORKBOOK

def load_and_standardize_files(directory):
    all_data = []
    search_pattern = os.path.join(directory, '*.[cx][sl]*[vxs]*')
    files = glob.glob(search_pattern)
    for file in files:
        try:
            df = pd.read_csv(file) if file.endswith('.csv') else pd.read_excel(file, engine='openpyxl')
            df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
            all_data.append(df)
        except Exception as e:
            print(f"Error reading {file}: {e}")
    return pd.concat(all_data, ignore_index=True) if all_data else pd.DataFrame()

# Truncated for brevity in boilerplate - refers to prior chat logic.
if __name__ == "__main__":
    print("Run the ETL pipeline here.")
