import requests
import json

# SEE CLOSURE WORKBOOK FOR API KEY SETUP
EBAY_OAUTH_TOKEN = 'YOUR_OAUTH_TOKEN' 

def create_inventory_item(sku, card_data):
    url = f"https://api.ebay.com/sell/inventory/v1/inventory_item/{sku}"
    headers = {
        'Authorization': f'Bearer {EBAY_OAUTH_TOKEN}',
        'Content-Language': 'en-US',
        'Content-Type': 'application/json'
    }
    payload = {
        "product": {
            "title": card_data['name'],
            "aspects": {
                "Game": ["Yu-Gi-Oh! TCG"],
                "Graded": ["No"],
                "Card Name": [card_data['name']]
            },
            "description": card_data['description']
        },
        "condition": "USED_EXCELLENT",
        "availability": {
            "shipToLocationAvailability": {"quantity": card_data['quantity']}
        }
    }
    response = requests.put(url, headers=headers, json=payload)
    return response.status_code

if __name__ == "__main__":
    print("eBay API Module Loaded.")
