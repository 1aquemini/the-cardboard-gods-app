import requests
import json

def fetch_card_prices(card_name):
    url = f"https://db.ygoprodeck.com/api/v7/cardinfo.php?name={card_name}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        prices = data['data'][0]['card_prices'][0]
        return {
            'tcgplayer_price': prices['tcgplayer_price'],
            'ebay_price': prices['ebay_price']
        }
    return None

if __name__ == "__main__":
    print(fetch_card_prices("Dark Magician"))
