# Performance Optimization Guide

## Database Optimization

### Indexes

**Current indexes:**
- cards.name (search optimization)
- cards.game (filtering)
- cards.set_name (filtering)
- inventory.card_id (foreign key)
- inventory.is_listed (filtering)
- market_prices.card_id (foreign key)
- market_prices.recorded_at (history queries)

**Consider adding:**
```sql
-- Composite index for common filter combinations
CREATE INDEX idx_inventory_condition_listed ON inventory(condition, is_listed);

-- Partial index for listed items
CREATE INDEX idx_inventory_listed_only ON inventory(card_id) WHERE is_listed = true;

-- Index for price lookups by source
CREATE INDEX idx_prices_source_card ON market_prices(source, card_id, recorded_at DESC);
```

### Query Optimization

**Use pagination:**
- Default per_page: 50
- Max per_page: 100
- Prevents loading entire tables

**Use eager loading:**
```python
# Avoid N+1 queries
from sqlalchemy.orm import joinedload
Card.query.options(joinedload(Card.inventory)).all()
```

**Cache frequently accessed data:**
```python
from flask_caching import Cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/api/cards/<id>')
@cache.cached(timeout=300)  # Cache for 5 minutes
def get_card(card_id):
    return Card.query.get(card_id)
```

## API Optimization

### Response Compression

```python
from flask_compress import Compress
Compress(app)
```

### JSON Serialization

- Use .to_dict() for selective fields
- Avoid serializing entire relationships unnecessarily
- Implement sparse fieldsets: `?fields=name,rarity`

### Caching Strategy

**Cache-Control Headers:**
```python
@app.route('/api/cards/<id>')
def get_card(card_id):
    response = make_response(card.to_dict())
    response.headers['Cache-Control'] = 'public, max-age=300'  # 5 min
    return response
```

## Backend Optimization

### Gunicorn Configuration

```bash
# Optimal for CPU-bound work
gunicorn --workers=4 --worker-class=sync --bind=0.0.0.0:5000 run:app

# For I/O-bound (database queries)
gunicorn --workers=8 --worker-class=gevent --bind=0.0.0.0:5000 run:app
```

**Calculate workers:**
```
workers = (2 × CPU_cores) + 1
```

### Connection Pooling

```python
# Already configured in SQLAlchemy
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_size': 10,
    'pool_recycle': 3600,
    'pool_pre_ping': True,
}
```

## Monitoring

### Key Metrics

- Response time (p50, p95, p99)
- Error rate
- Database query time
- Active connections
- Memory usage
- CPU usage

### Tools

- **Datadog** - APM & monitoring
- **New Relic** - Performance monitoring
- **Sentry** - Error tracking
- **Prometheus** - Metrics collection

## Load Testing

```bash
# Using Apache Bench
ab -n 1000 -c 10 http://localhost:5000/api/cards

# Using wrk
wrk -t12 -c400 -d30s http://localhost:5000/api/cards

# Using locust
locust -f locustfile.py --host=http://localhost:5000
```

## Frontend Optimization

- Enable gzip compression
- Minify CSS/JS
- Lazy load images
- Code splitting
- Use CDN for static assets
- Service workers for offline support

## Database Maintenance

```sql
-- Vacuum and analyze regularly
VACUUM ANALYZE;

-- Check index bloat
SELECT schemaname, tablename, indexname 
FROM pg_indexes 
WHERE schemaname NOT IN ('pg_catalog', 'information_schema');

-- Monitor slow queries
SET log_min_duration_statement = 1000;  -- Log queries over 1s
```
