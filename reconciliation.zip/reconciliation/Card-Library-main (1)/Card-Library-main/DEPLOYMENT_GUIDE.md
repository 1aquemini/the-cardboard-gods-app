# Production Deployment Guide

## Quick Deploy to Railway.app

### Prerequisites
- Railway account (https://railway.app)
- GitHub repo connected
- Environment variables configured

### Step 1: Connect Repository

1. Go to Railway Dashboard
2. Click "New Project"
3. Select "Deploy from GitHub"
4. Connect your GitHub account and select `Card-Library`

### Step 2: Configure Environment

1. Go to Project Settings → Variables
2. Add environment variables:

```
FLASK_ENV=production
SECRET_KEY=<generate-random-secure-key>
DATABASE_URL=<railway-postgres-url>
EBAY_OAUTH_TOKEN=<your-token>
CORS_ORIGINS=https://yourdomain.com
```

### Step 3: Deploy

1. Railway auto-deploys on git push to main
2. Or manually trigger: Dashboard → Redeploy
3. Monitor logs: Dashboard → Logs

### Step 4: Configure Custom Domain

1. Project Settings → Domains
2. Add custom domain: `api.yourdomain.com`
3. Update DNS records (CNAME)
4. SSL/TLS auto-configured

### Step 5: Monitor

1. Set up alerts: Project → Alerts
2. Monitor logs: Dashboard → Logs
3. Check health: `curl https://api.yourdomain.com/health`

---

## Deploy with Docker to Production

### Build Image

```bash
cd v2-cardboard-gods/backend
docker build -t cardboard-gods:latest .
```

### Push to Registry

```bash
# Docker Hub
docker tag cardboard-gods:latest yourusername/cardboard-gods:latest
docker push yourusername/cardboard-gods:latest

# Or GitHub Container Registry
docker tag cardboard-gods:latest ghcr.io/1aquemini/cardboard-gods:latest
docker push ghcr.io/1aquemini/cardboard-gods:latest
```

### Deploy with docker-compose

```bash
# Create docker-compose.prod.yml
docker-compose -f docker-compose.prod.yml up -d
```

---

## Environment Setup

### Production .env

```bash
# Database (use managed PostgreSQL)
DATABASE_URL=postgresql://user:password@prod-db.railway.app:5432/cardboard_gods

# Flask
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=$(python -c 'import secrets; print(secrets.token_hex(32))')

# APIs
EBAY_OAUTH_TOKEN=your-production-token

# CORS (restrict to your domain)
CORS_ORIGINS=https://yourdomain.com,https://api.yourdomain.com

# Logging
LOG_LEVEL=INFO
```

---

## Post-Deployment Checklist

- [ ] Health check: `curl https://api.yourdomain.com/health`
- [ ] Database connectivity verified
- [ ] Price sync running
- [ ] Logs being written
- [ ] Error rate < 0.1%
- [ ] Response times acceptable (p95 < 500ms)
- [ ] HTTPS working
- [ ] Rate limiting active
- [ ] Backups scheduled
- [ ] Monitoring alerts configured

---

## Scaling

### Horizontal Scaling

1. Railway auto-scales on CPU/Memory
2. Configure in Project Settings → Scaling
3. Monitor: Dashboard → Metrics

### Vertical Scaling

1. Upgrade database: Settings → Resources
2. Upgrade API servers: Settings → Instances
3. Monitor resource usage

---

## Troubleshooting

### Application won't start

```bash
# Check logs
railway logs

# Verify environment variables
railway vars

# Check database connection
psql $DATABASE_URL -c "SELECT 1"
```

### High error rate

1. Check logs: `railway logs --follow`
2. Check database status
3. Check rate limiting
4. Rollback if needed: `railway rollback <deployment-id>`

### Slow responses

1. Check database queries
2. Check API metrics
3. Scale up resources
4. Optimize slow queries

---

## Support

- Railway Docs: https://docs.railway.app
- Flask Deployment: https://flask.palletsprojects.com/en/2.3.x/deploying/
- PostgreSQL Connection: https://www.postgresql.org/docs/current/libpq-envars.html
