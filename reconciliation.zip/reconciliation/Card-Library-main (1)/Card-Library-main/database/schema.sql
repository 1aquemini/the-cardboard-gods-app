-- 1. Canonical Card Dictionary
CREATE TABLE Cards (
    card_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    game VARCHAR(50) DEFAULT 'Yu-Gi-Oh!',
    card_type VARCHAR(50),
    attribute VARCHAR(50),
    rarity VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Physical Inventory
CREATE TABLE Inventory (
    sku SERIAL PRIMARY KEY,
    card_id VARCHAR(50) REFERENCES Cards(card_id),
    condition VARCHAR(50) NOT NULL,
    language VARCHAR(50) DEFAULT 'English',
    quantity INT DEFAULT 1,
    cost_basis DECIMAL(10, 2),
    location VARCHAR(100),
    is_listed BOOLEAN DEFAULT FALSE,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Live Market Data
CREATE TABLE MarketPrices (
    card_id VARCHAR(50) REFERENCES Cards(card_id),
    source VARCHAR(50),
    market_price DECIMAL(10, 2),
    lowest_listing DECIMAL(10, 2),
    currency VARCHAR(10) DEFAULT 'USD',
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (card_id, source)
);
