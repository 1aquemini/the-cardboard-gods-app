# Deployment Checklist

## Pre-Deployment

### Code Quality
- [ ] All tests passing: `pytest v2-cardboard-gods/backend/test_api.py`
- [ ] No linting errors: `flake8 v2-cardboard-gods/backend`
- [ ] Code coverage > 80%: `pytest --cov`
- [ ] Security audit passed: `pip-audit`, `safety check`
- [ ] All dependencies up-to-date
- [ ] No hardcoded secrets or credentials
- [ ] Documentation is current
- [ ] Changelog updated

### Configuration
- [ ] Environment variables configured
- [ ] Database URL set to production database
- [ ] `SECRET_KEY` is strong and random
- [ ] `FLASK_ENV=production`
- [ ] `DEBUG=False`
- [ ] CORS origins set correctly
- [ ] Logging configured
- [ ] Email/alerting configured

### Database
- [ ] Production database created
- [ ] Backup strategy implemented
- [ ] Database migrations tested
- [ ] Indexes created
- [ ] Connection pooling configured
- [ ] SSL/TLS enabled
- [ ] Regular backups scheduled

### Infrastructure
- [ ] SSL/TLS certificate installed
- [ ] DNS records configured
- [ ] Firewall rules configured
- [ ] Load balancer configured
- [ ] Auto-scaling configured (if needed)
- [ ] Health checks configured
- [ ] Monitoring/alerting set up
- [ ] Log aggregation configured

## Deployment Steps

### 1. Build Docker Image

```bash
cd v2-cardboard-gods/backend
docker build -t cardboard-gods:latest .
docker tag cardboard-gods:latest myregistry/cardboard-gods:v2.0.0
docker push myregistry/cardboard-gods:v2.0.0
```

### 2. Update Database

```bash
# Run migrations (if using Alembic)
alembic upgrade head

# Or initialize fresh database
python run.py  # Creates tables
```

### 3. Deploy Application

**Railway.app:**
```bash
railway link
railway up
```

**Docker Swarm:**
```bash
docker service update --image myregistry/cardboard-gods:v2.0.0 cardboard_gods_api
```

**Kubernetes:**
```bash
kubectl set image deployment/cardboard-gods-api \
  api=myregistry/cardboard-gods:v2.0.0
```

### 4. Verify Deployment

```bash
# Health check
curl https://api.yourdomain.com/health

# Check logs
docker logs -f <container_id>

# Test endpoints
curl https://api.yourdomain.com/api/cards?per_page=1

# Monitor resources
docker stats
```

## Post-Deployment

### Monitoring
- [ ] Monitor error rate (should be < 0.1%)
- [ ] Monitor response times (p95 < 500ms)
- [ ] Monitor database connections
- [ ] Monitor server resources (CPU, memory)
- [ ] Monitor error logs for issues
- [ ] Monitor rate limiting
- [ ] Set up alerts for critical issues

### Validation
- [ ] All endpoints responding
- [ ] Database connectivity working
- [ ] Price sync running
- [ ] ETL pipeline working
- [ ] eBay integration working
- [ ] Logs being written
- [ ] Backups running

### Communication
- [ ] Notify team of deployment
- [ ] Update status page
- [ ] Notify users if applicable
- [ ] Document any issues encountered

## Rollback Plan

If deployment fails:

```bash
# Revert to previous version
docker service update --image myregistry/cardboard-gods:v1.9.9 cardboard_gods_api

# Rollback database migrations
alembic downgrade -1

# Monitor logs
docker logs -f cardboard_gods_api

# Notify team
# Post-mortem after stable
```

## Production Support

### On-Call Runbook

**High Error Rate:**
1. Check error logs: `docker logs cardboard_gods_api | grep ERROR`
2. Check database connectivity
3. Check resource usage
4. Restart service if needed: `docker service restart cardboard_gods_api`

**High Response Times:**
1. Check database query performance
2. Check active connections
3. Check API rate limiting
4. Scale horizontally if needed

**Database Issues:**
1. Check connection count: `SELECT count(*) FROM pg_stat_activity;`
2. Kill idle connections if needed
3. Analyze slow queries
4. Restore from backup if necessary

## Maintenance Windows

**Schedule:**
- Weekly: Check logs, update dependencies
- Monthly: Review performance metrics, optimize slow queries
- Quarterly: Security audit, dependency update, disaster recovery test

**Notifications:**
- Announce maintenance 24 hours in advance
- Planned downtime should be < 15 minutes
- Have rollback plan ready
