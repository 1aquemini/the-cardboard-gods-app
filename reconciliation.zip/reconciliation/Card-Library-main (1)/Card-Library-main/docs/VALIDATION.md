# Inventory validation notes

`data/ygo_for_sale_inventory.csv` is treated as existing ground truth for
already-priced Yu-Gi-Oh "for sale" listings (asking prices, not graded
valuations) — not something to re-derive.

**Note on counts:** the project brief references 711 listings / 2,045
physical cards as of 2026-07-27. The file actually available in project
knowledge contains 82 listings totaling 225 physical cards (summed
`Quantity` column) as of this repo's creation. Flagging this discrepancy
rather than assuming one number is correct — if a fuller export exists,
replace `data/ygo_for_sale_inventory.csv` with it and update this note.

Magic and Pokemon inventory has not been provided yet. Don't assume 0 cards
in those games — treat as pending upload.
