# Card Library v1 - HTML Desktop Version

Original iteration of the card inventory management app built with HTML/CSS/JavaScript.

## Overview

This is a static HTML desktop application for managing trading card inventories. It provides a basic interface for cataloging and pricing Yu-Gi-Oh!, Magic: The Gathering, and Pokémon cards.

## Features

- Desktop-based card inventory tracking
- Photo-based condition grading (reference in `docs/GRADING_REFERENCE.md`)
- Price estimation using comparable sales data
- CSV export/import

## Status

**Deprecated in favor of v2 (Cardboard Gods)** — See the main README for information about the mobile-first Python backend version.

Files from this version are archived here for reference on the original design approach.
