# Card Library — Dual Version Project

A comprehensive trading card inventory management system with two versions:
- **v1 (Card Library)**: HTML desktop application for card tracking
- **v2 (Cardboard Gods)**: Cross-platform mobile + desktop app with camera scanning and real-time price lookups

## Project Overview

This repository contains the evolution of a trading card management system, from a basic HTML desktop interface to a full-stack mobile-responsive application with Python backend, PostgreSQL database, and external API integrations for live market pricing.

## Directory Structure

```
Card-Library/
├── v1-card-library/              # Version 1: HTML Desktop App
│   ├── index.html
│   ├── assets/
│   ├── styles/
│   └── README.md
│
├── v2-cardboard-gods/            # Version 2: Cross-Platform Mobile + Desktop
│   ├── backend/                  # Python backend (APIs + ETL)
│   │   ├── src/
│   │   │   ├── api/              # External API integrations
│   │   │   │   ├── ebay_inventory.py
│   │   │   │   └── ygoprodeck.py
│   │   │   └── etl/              # Data pipeline
│   │   │       └── data_merger.py
│   │   ├── database/
│   │   │   └── schema.sql
│   │   ├── requirements.txt
│   │   └── README.md
│   │
│   ├── frontend/                 # Cross-platform UI (Phone + Desktop)
│   │   ├── src/
│   │   ├── public/
│   │   ├── package.json
│   │   └── README.md
│   │
│   ├── data/
│   │   └── raw/                  # Raw CSV/XLSX input files
│   │
│   ├── docs/                     # Configuration & Architecture Reference
│   │   ├── GRADING_REFERENCE.md
│   │   ├── VALIDATION.md
│   │   └── SCHEMA_REFERENCE.md
│   │
│   ├── CLOSURE_WORKBOOK.csv      # Setup checklist (API keys, DB config)
│   └── README.md                 # v2 Project Overview
│
└── README.md                     # This file
```

## Quick Start by Version

### Version 1 (Card Library - HTML Desktop)
See [v1-card-library/README.md](v1-card-library/README.md) for details.

### Version 2 (Cardboard Gods - Mobile + Desktop)
**Recommended for active development.**

See [v2-cardboard-gods/README.md](v2-cardboard-gods/README.md) for:
- Backend setup (Python + PostgreSQL)
- Frontend setup (cross-platform UI)
- Camera scanning configuration
- API integrations (eBay, YGO ProDeck)
- ETL pipeline documentation

## Version Comparison

| Feature | v1 (Card Library) | v2 (Cardboard Gods) |
|---------|-------------------|---------------------|
| Platform | Desktop (HTML) | Mobile + Desktop |
| Camera Scanning | ❌ | ✅ |
| Real-time Pricing | ❌ | ✅ (via APIs) |
| Database | CSV/Manual | PostgreSQL |
| Backend | None | Python (APIs + ETL) |
| UI Responsiveness | ❌ | ✅ Cross-platform |
| eBay Integration | ❌ | ✅ |
| Development Status | Archive | Active |

## Key Technologies

### v2 Backend
- **Python 3.x** — Core backend
- **PostgreSQL** — Card database & inventory
- **SQLAlchemy** — ORM
- **Requests** — External API calls
- **Pandas** — Data processing

### v2 Frontend
- **Cross-platform framework** (to be determined)
- **Camera API** for card scanning
- **Responsive design** (phone + tablet + desktop)

### External APIs
- **YGO ProDeck** — Yu-Gi-Oh card data & pricing
- **eBay** — Inventory listing & market data

## Configuration & References

All configuration references and architectural documentation are in `v2-cardboard-gods/docs/`:
- `GRADING_REFERENCE.md` — Photo-based condition grading scale
- `VALIDATION.md` — Data quality notes
- `SCHEMA_REFERENCE.md` — Card data schema & architecture

See `v2-cardboard-gods/CLOSURE_WORKBOOK.csv` for setup checklist.

## Next Steps

1. **v2 Backend Setup**
   - [ ] Configure PostgreSQL database
   - [ ] Set up eBay API credentials
   - [ ] Install Python dependencies
   - [ ] Run ETL pipeline

2. **v2 Frontend Development**
   - [ ] Choose cross-platform framework
   - [ ] Implement camera scanning UI
   - [ ] Build card search & price display
   - [ ] Test on mobile & desktop

3. **Integration**
   - [ ] Connect frontend to backend APIs
   - [ ] Implement real-time price updates
   - [ ] Test end-to-end workflow

## Contributing

When adding features, ensure they work on both mobile and desktop platforms for v2.

## License

(Add license info as needed)

---

**Questions?** Check the README in your target version directory (v1 or v2).
