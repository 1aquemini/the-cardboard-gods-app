from flask import Blueprint, jsonify
from app import db

health_bp = Blueprint('health', __name__)

@health_bp.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    try:
        db.session.execute('SELECT 1')
        return jsonify({
            'status': 'healthy',
            'database': 'connected'
        }), 200
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'database': 'disconnected',
            'error': str(e)
        }), 503

@health_bp.route('/api/version', methods=['GET'])
def version():
    """Get API version"""
    return jsonify({
        'version': '2.0.0',
        'name': 'Cardboard Gods API',
        'status': 'beta'
    }), 200
