from flask import Blueprint, jsonify, request
from app import db, limiter
from models import Inventory, Card

inventory_bp = Blueprint('inventory', __name__, url_prefix='/inventory')

@inventory_bp.route('', methods=['GET'])
@limiter.limit("100 per minute")
def get_inventory():
    """List inventory items with filtering"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    condition = request.args.get('condition')
    is_listed = request.args.get('is_listed')
    location = request.args.get('location')
    
    query = Inventory.query
    
    if condition:
        query = query.filter_by(condition=condition)
    if is_listed is not None:
        query = query.filter_by(is_listed=is_listed.lower() == 'true')
    if location:
        query = query.filter_by(location=location)
    
    items = query.order_by(Inventory.last_updated.desc()).paginate(page=page, per_page=per_page)
    return jsonify({
        'total': items.total,
        'pages': items.pages,
        'current_page': page,
        'per_page': per_page,
        'data': [i.to_dict() for i in items.items]
    }), 200

@inventory_bp.route('/<int:sku>', methods=['GET'])
@limiter.limit("200 per minute")
def get_inventory_item(sku):
    """Get specific inventory item"""
    item = Inventory.query.get(sku)
    if not item:
        return jsonify({'error': 'Inventory item not found'}), 404
    return jsonify(item.to_dict()), 200

@inventory_bp.route('', methods=['POST'])
@limiter.limit("50 per minute")
def add_inventory():
    """Add new inventory item"""
    data = request.get_json()
    
    if not data or 'card_id' not in data or 'condition' not in data:
        return jsonify({'error': 'Missing required fields: card_id, condition'}), 400
    
    # Verify card exists
    card = Card.query.get(data['card_id'])
    if not card:
        return jsonify({'error': f'Card {data["card_id"]} not found'}), 404
    
    # Validate condition against grading scale
    valid_conditions = ['Gem Mint', 'Mint', 'Near Mint', 'Excellent', 'Very Good', 'Good', 'Fair', 'Poor']
    if data['condition'] not in valid_conditions:
        return jsonify({'error': f'Invalid condition. Must be one of: {valid_conditions}'}), 400
    
    try:
        item = Inventory(
            card_id=data['card_id'],
            condition=data['condition'],
            quantity=data.get('quantity', 1),
            cost_basis=data.get('cost_basis', 0),
            location=data.get('location', 'Unknown'),
            photo_ref=data.get('photo_ref'),
            notes=data.get('notes'),
            language=data.get('language', 'English')
        )
        db.session.add(item)
        db.session.commit()
        return jsonify(item.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@inventory_bp.route('/<int:sku>', methods=['PUT'])
@limiter.limit("50 per minute")
def update_inventory(sku):
    """Update inventory item"""
    item = Inventory.query.get(sku)
    if not item:
        return jsonify({'error': 'Inventory item not found'}), 404
    
    data = request.get_json()
    try:
        updatable_fields = ['condition', 'language', 'quantity', 'cost_basis', 'location', 'is_listed', 'photo_ref', 'notes']
        for field in updatable_fields:
            if field in data:
                setattr(item, field, data[field])
        db.session.commit()
        return jsonify(item.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@inventory_bp.route('/<int:sku>', methods=['DELETE'])
def delete_inventory(sku):
    """Delete inventory item"""
    item = Inventory.query.get(sku)
    if not item:
        return jsonify({'error': 'Inventory item not found'}), 404
    
    try:
        db.session.delete(item)
        db.session.commit()
        return jsonify({'message': 'Inventory item deleted'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@inventory_bp.route('/stats/summary', methods=['GET'])
@limiter.limit("50 per minute")
def inventory_stats():
    """Get inventory statistics"""
    total_items = Inventory.query.count()
    total_quantity = db.session.query(db.func.sum(Inventory.quantity)).scalar() or 0
    total_cost = db.session.query(db.func.sum(Inventory.cost_basis)).scalar() or 0
    listed_items = Inventory.query.filter_by(is_listed=True).count()
    
    # By condition
    by_condition = db.session.query(Inventory.condition, db.func.count(Inventory.sku)).group_by(Inventory.condition).all()
    
    return jsonify({
        'total_line_items': total_items,
        'total_cards': total_quantity,
        'total_cost_basis': total_cost,
        'listed_items': listed_items,
        'by_condition': {cond: count for cond, count in by_condition}
    }), 200
