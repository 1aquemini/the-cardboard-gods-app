from flask import Blueprint, jsonify, request
from app import db, limiter
from models import MarketPrice, Card
from datetime import datetime, timedelta

prices_bp = Blueprint('prices', __name__, url_prefix='/prices')

@prices_bp.route('/<card_id>', methods=['GET'])
@limiter.limit("200 per minute")
def get_prices(card_id):
    """Get current market prices for a card from all sources"""
    card = Card.query.get(card_id)
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    
    prices = MarketPrice.query.filter_by(card_id=card_id).all()
    if not prices:
        return jsonify({'data': [], 'avg_price': None}), 200
    
    price_data = [p.to_dict() for p in prices]
    avg = card._calculate_avg_price()
    
    return jsonify({
        'card_id': card_id,
        'card_name': card.name,
        'data': price_data,
        'avg_price': avg
    }), 200

@prices_bp.route('', methods=['POST'])
@limiter.limit("50 per minute")
def add_price():
    """Add/update market price for a card"""
    data = request.get_json()
    
    if not data or 'card_id' not in data or 'source' not in data:
        return jsonify({'error': 'Missing required fields: card_id, source'}), 400
    
    card = Card.query.get(data['card_id'])
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    
    try:
        # Update or create price record
        price = MarketPrice.query.filter_by(
            card_id=data['card_id'],
            source=data['source']
        ).first()
        
        if price:
            price.market_price = data.get('market_price')
            price.lowest_listing = data.get('lowest_listing')
            price.highest_listing = data.get('highest_listing')
            price.num_listings = data.get('num_listings')
            price.currency = data.get('currency', 'USD')
            price.recorded_at = datetime.utcnow()
        else:
            price = MarketPrice(
                card_id=data['card_id'],
                source=data['source'],
                market_price=data.get('market_price'),
                lowest_listing=data.get('lowest_listing'),
                highest_listing=data.get('highest_listing'),
                num_listings=data.get('num_listings'),
                currency=data.get('currency', 'USD')
            )
            db.session.add(price)
        
        db.session.commit()
        return jsonify(price.to_dict()), 201 if not price.id else 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@prices_bp.route('/source/<source>', methods=['GET'])
@limiter.limit("100 per minute")
def get_prices_by_source(source):
    """Get all prices from a specific source"""
    valid_sources = ['ygoprodeck', 'ebay', 'tcgplayer']
    if source not in valid_sources:
        return jsonify({'error': f'Invalid source. Must be one of: {valid_sources}'}), 400
    
    page = request.args.get('page', 1, type=int)
    prices = MarketPrice.query.filter_by(source=source).order_by(MarketPrice.recorded_at.desc()).paginate(page=page, per_page=50)
    
    return jsonify({
        'source': source,
        'total': prices.total,
        'pages': prices.pages,
        'current_page': page,
        'data': [p.to_dict() for p in prices.items]
    }), 200

@prices_bp.route('/history/<card_id>', methods=['GET'])
@limiter.limit("100 per minute")
def get_price_history(card_id):
    """Get price history for a card (last 30 days)"""
    card = Card.query.get(card_id)
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    prices = MarketPrice.query.filter(
        MarketPrice.card_id == card_id,
        MarketPrice.recorded_at >= thirty_days_ago
    ).order_by(MarketPrice.recorded_at.asc()).all()
    
    return jsonify({
        'card_id': card_id,
        'card_name': card.name,
        'period': '30 days',
        'data': [p.to_dict() for p in prices]
    }), 200

@prices_bp.route('/outdated', methods=['GET'])
@limiter.limit("20 per minute")
def get_outdated_prices():
    """Get cards with prices older than 7 days (for sync)"""
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    
    outdated = db.session.query(MarketPrice).filter(
        MarketPrice.recorded_at < seven_days_ago
    ).all()
    
    card_ids = list(set([p.card_id for p in outdated]))
    
    return jsonify({
        'outdated_count': len(card_ids),
        'card_ids': card_ids,
        'message': 'Run price sync on these cards'
    }), 200
