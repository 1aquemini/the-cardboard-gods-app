from flask import Blueprint, jsonify, request
from app import db, limiter
from models import Card
from sqlalchemy import or_

cards_bp = Blueprint('cards', __name__, url_prefix='/cards')

@cards_bp.route('', methods=['GET'])
@limiter.limit("100 per minute")
def get_cards():
    """List all cards with pagination and filtering"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    game = request.args.get('game')
    rarity = request.args.get('rarity')
    set_name = request.args.get('set')
    
    query = Card.query
    
    if game:
        query = query.filter_by(game=game)
    if rarity:
        query = query.filter_by(rarity=rarity)
    if set_name:
        query = query.filter_by(set_name=set_name)
    
    cards = query.order_by(Card.name).paginate(page=page, per_page=per_page)
    return jsonify({
        'total': cards.total,
        'pages': cards.pages,
        'current_page': page,
        'per_page': per_page,
        'data': [c.to_dict() for c in cards.items]
    }), 200

@cards_bp.route('/<card_id>', methods=['GET'])
@limiter.limit("200 per minute")
def get_card(card_id):
    """Get card details with pricing and inventory"""
    card = Card.query.get(card_id)
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    return jsonify(card.to_dict_detailed()), 200

@cards_bp.route('/search', methods=['GET'])
@limiter.limit("100 per minute")
def search_cards():
    """Search cards by name, game, or set"""
    query = request.args.get('q', '').strip()
    game = request.args.get('game')
    
    if len(query) < 2:
        return jsonify({'error': 'Query must be at least 2 characters'}), 400
    
    search_filter = Card.name.ilike(f'%{query}%') | Card.set_name.ilike(f'%{query}%')
    
    cards_query = Card.query.filter(search_filter)
    if game:
        cards_query = cards_query.filter_by(game=game)
    
    cards = cards_query.limit(50).all()
    return jsonify([c.to_dict() for c in cards]), 200

@cards_bp.route('', methods=['POST'])
def create_card():
    """Create a new card entry"""
    data = request.get_json()
    
    if not data or not all(k in data for k in ['card_id', 'name', 'game']):
        return jsonify({'error': 'Missing required fields: card_id, name, game'}), 400
    
    if Card.query.get(data['card_id']):
        return jsonify({'error': 'Card ID already exists'}), 409
    
    try:
        card = Card(
            card_id=data['card_id'],
            name=data['name'],
            game=data['game'],
            card_type=data.get('card_type'),
            attribute=data.get('attribute'),
            rarity=data.get('rarity'),
            description=data.get('description'),
            set_name=data.get('set_name'),
            set_code=data.get('set_code'),
            card_number=data.get('card_number')
        )
        db.session.add(card)
        db.session.commit()
        return jsonify(card.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@cards_bp.route('/<card_id>', methods=['PUT'])
def update_card(card_id):
    """Update card details"""
    card = Card.query.get(card_id)
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    
    data = request.get_json()
    try:
        for key in ['name', 'game', 'card_type', 'attribute', 'rarity', 'description', 'set_name', 'set_code', 'card_number']:
            if key in data:
                setattr(card, key, data[key])
        db.session.commit()
        return jsonify(card.to_dict()), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400

@cards_bp.route('/<card_id>', methods=['DELETE'])
def delete_card(card_id):
    """Delete a card (cascades to inventory and prices)"""
    card = Card.query.get(card_id)
    if not card:
        return jsonify({'error': 'Card not found'}), 404
    
    try:
        db.session.delete(card)
        db.session.commit()
        return jsonify({'message': 'Card deleted successfully'}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 400
