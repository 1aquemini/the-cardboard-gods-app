import logging
from apscheduler.schedulers.background import BackgroundScheduler
from src.api.ygoprodeck import YGOProDeckAPI
from models import Card, MarketPrice
from app import db
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PriceSync:
    """Sync prices from external APIs on a schedule"""
    
    @staticmethod
    def sync_ygoprodeck_prices():
        """Fetch latest prices from YGO ProDeck for all cards"""
        logger.info("Starting YGO ProDeck price sync...")
        try:
            cards = Card.query.filter_by(game='Yu-Gi-Oh!').all()
            synced = 0
            errors = 0
            
            for card in cards:
                try:
                    price_data = YGOProDeckAPI.fetch_prices(card.name)
                    if price_data:
                        # Update or create price record
                        existing = MarketPrice.query.filter_by(
                            card_id=card.card_id,
                            source='ygoprodeck'
                        ).first()
                        
                        if existing:
                            existing.market_price = price_data['market_price']
                            existing.lowest_listing = price_data['lowest_listing']
                            existing.recorded_at = datetime.utcnow()
                        else:
                            new_price = MarketPrice(
                                card_id=card.card_id,
                                source='ygoprodeck',
                                market_price=price_data['market_price'],
                                lowest_listing=price_data['lowest_listing'],
                                currency='USD'
                            )
                            db.session.add(new_price)
                        
                        synced += 1
                except Exception as e:
                    logger.error(f"Error syncing {card.name}: {e}")
                    errors += 1
            
            db.session.commit()
            logger.info(f"YGO ProDeck sync complete: {synced} synced, {errors} errors")
        except Exception as e:
            logger.error(f"YGO ProDeck sync failed: {e}")
            db.session.rollback()
    
    @staticmethod
    def start_scheduler():
        """Start background scheduler for price syncs"""
        scheduler = BackgroundScheduler()
        
        # Sync prices every 24 hours
        scheduler.add_job(
            PriceSync.sync_ygoprodeck_prices,
            'interval',
            hours=24,
            id='ygoprodeck_sync',
            name='YGO ProDeck Price Sync'
        )
        
        scheduler.start()
        logger.info("Price sync scheduler started")
        return scheduler
