import os
import glob
import logging
import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
from dotenv import load_dotenv
import sys

load_dotenv()

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class ETLPipeline:
    def __init__(self, db_connection_string):
        self.engine = create_engine(db_connection_string)
        self.raw_data_dir = os.path.join(os.path.dirname(__file__), '../../data/raw')
        self.processed_count = 0
        self.error_count = 0
    
    def load_raw_files(self):
        """Load all CSV and XLSX files from data/raw directory"""
        logger.info(f"Loading raw files from {self.raw_data_dir}")
        all_data = []
        
        if not os.path.exists(self.raw_data_dir):
            logger.warning(f"Raw data directory not found: {self.raw_data_dir}")
            return pd.DataFrame()
        
        # Find all CSV and XLSX files
        csv_files = glob.glob(os.path.join(self.raw_data_dir, '*.csv'))
        xlsx_files = glob.glob(os.path.join(self.raw_data_dir, '*.xlsx'))
        
        for file in csv_files + xlsx_files:
            try:
                logger.info(f"Reading {file}")
                if file.endswith('.csv'):
                    df = pd.read_csv(file)
                else:
                    df = pd.read_excel(file, engine='openpyxl')
                
                logger.info(f"Loaded {len(df)} rows from {os.path.basename(file)}")
                all_data.append(df)
            except Exception as e:
                logger.error(f"Error reading {file}: {e}")
                self.error_count += 1
        
        if not all_data:
            logger.warning("No data files found")
            return pd.DataFrame()
        
        combined = pd.concat(all_data, ignore_index=True)
        logger.info(f"Combined {len(combined)} total rows")
        return combined
    
    def standardize_columns(self, df):
        """Normalize column names"""
        if df.empty:
            return df
        
        df.columns = [col.strip().lower().replace(' ', '_').replace('-', '_') for col in df.columns]
        return df
    
    def process_cards(self, df):
        """Insert/update cards into database"""
        logger.info("Processing cards...")
        
        # Expected columns: card_id, name, game, card_type, set_name, etc.
        required_cols = ['name', 'game']
        missing = [col for col in required_cols if col not in df.columns]
        
        if missing:
            logger.warning(f"Missing columns: {missing}. Attempting to map common names...")
            # Try to auto-map common column names
            col_mapping = {
                'card name': 'name',
                'card_name': 'name',
                'title': 'name',
                'game type': 'game',
                'card type': 'card_type',
                'set': 'set_name'
            }
            df = df.rename(columns=col_mapping)
        
        try:
            # Create card_id if missing
            if 'card_id' not in df.columns:
                df['card_id'] = range(1, len(df) + 1)
            
            cards_df = df[['card_id', 'name', 'game']].drop_duplicates()
            cards_df.to_sql('cards', self.engine, if_exists='append', index=False)
            self.processed_count += len(cards_df)
            logger.info(f"Inserted {len(cards_df)} cards")
        except Exception as e:
            logger.error(f"Error processing cards: {e}")
            self.error_count += 1
    
    def process_inventory(self, df):
        """Insert inventory items into database"""
        logger.info("Processing inventory...")
        
        required_cols = ['card_id', 'condition']
        if not all(col in df.columns for col in required_cols):
            logger.warning("Missing required inventory columns")
            return
        
        try:
            # Map condition grades if present
            if 'grade' in df.columns:
                grade_mapping = {
                    10: 'Gem Mint', 9: 'Mint', 8: 'Near Mint', 7: 'Excellent',
                    6: 'Very Good', 5: 'Good', 3: 'Fair', 1: 'Poor'
                }
                df['condition'] = df['grade'].map(grade_mapping)
            
            inventory_df = df[['card_id', 'condition']].copy()
            inventory_df['quantity'] = df.get('quantity', 1)
            inventory_df['location'] = df.get('location', 'Unknown')
            
            inventory_df.to_sql('inventory', self.engine, if_exists='append', index=False)
            self.processed_count += len(inventory_df)
            logger.info(f"Inserted {len(inventory_df)} inventory items")
        except Exception as e:
            logger.error(f"Error processing inventory: {e}")
            self.error_count += 1
    
    def run(self):
        """Execute full ETL pipeline"""
        logger.info("Starting ETL pipeline...")
        start_time = datetime.utcnow()
        
        # Step 1: Load
        df = self.load_raw_files()
        if df.empty:
            logger.warning("No data to process")
            return
        
        # Step 2: Standardize
        df = self.standardize_columns(df)
        
        # Step 3: Process
        self.process_cards(df)
        self.process_inventory(df)
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        logger.info(f"ETL complete. Processed: {self.processed_count}, Errors: {self.error_count}, Duration: {duration:.2f}s")

if __name__ == '__main__':
    db_url = os.getenv('DATABASE_URL', 'postgresql://localhost:5432/cardboard_gods')
    pipeline = ETLPipeline(db_url)
    pipeline.run()
