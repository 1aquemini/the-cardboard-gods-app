import requests
import logging
from datetime import datetime
import os

logger = logging.getLogger(__name__)

class EBayInventoryAPI:
    BASE_URL = "https://api.ebay.com/sell/inventory/v1"
    OAUTH_TOKEN = os.getenv('EBAY_OAUTH_TOKEN')
    
    @staticmethod
    def get_headers():
        return {
            'Authorization': f'Bearer {EBayInventoryAPI.OAUTH_TOKEN}',
            'Content-Type': 'application/json',
            'Content-Language': 'en-US'
        }
    
    @staticmethod
    def create_inventory_item(sku, inventory_data):
        """Create or update inventory item on eBay"""
        if not EBayInventoryAPI.OAUTH_TOKEN:
            logger.warning("eBay OAuth token not configured")
            return {'status': 'skipped', 'message': 'eBay token not configured'}
        
        try:
            url = f"{EBayInventoryAPI.BASE_URL}/inventory_item/{sku}"
            payload = {
                "sku": str(sku),
                "condition": "USED_EXCELLENT",  # Map from grading scale
                "product": {
                    "title": inventory_data.get('card_name', 'Trading Card'),
                    "description": inventory_data.get('notes', ''),
                    "aspects": {
                        "Game": [inventory_data.get('game', 'Yu-Gi-Oh!')],
                        "Language": [inventory_data.get('language', 'English')],
                        "Card Name": [inventory_data.get('card_name', '')]
                    }
                },
                "availability": {
                    "shipToLocationAvailability": [
                        {
                            "quantity": inventory_data.get('quantity', 1)
                        }
                    ]
                }
            }
            
            response = requests.put(
                url,
                json=payload,
                headers=EBayInventoryAPI.get_headers(),
                timeout=10
            )
            
            if response.status_code in [200, 201]:
                return {'status': 'success', 'sku': sku}
            else:
                logger.error(f"eBay API error: {response.status_code} - {response.text}")
                return {'status': 'error', 'message': response.text}
        except requests.RequestException as e:
            logger.error(f"eBay inventory creation error: {e}")
            return {'status': 'error', 'message': str(e)}
    
    @staticmethod
    def get_inventory_item(sku):
        """Retrieve inventory item from eBay"""
        if not EBayInventoryAPI.OAUTH_TOKEN:
            return None
        
        try:
            url = f"{EBayInventoryAPI.BASE_URL}/inventory_item/{sku}"
            response = requests.get(
                url,
                headers=EBayInventoryAPI.get_headers(),
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"eBay inventory retrieval error: {e}")
            return None
    
    @staticmethod
    def delete_inventory_item(sku):
        """Delete inventory item from eBay"""
        if not EBayInventoryAPI.OAUTH_TOKEN:
            return {'status': 'skipped'}
        
        try:
            url = f"{EBayInventoryAPI.BASE_URL}/inventory_item/{sku}"
            response = requests.delete(
                url,
                headers=EBayInventoryAPI.get_headers(),
                timeout=10
            )
            return {'status': 'success' if response.status_code == 204 else 'error'}
        except requests.RequestException as e:
            logger.error(f"eBay inventory deletion error: {e}")
            return {'status': 'error', 'message': str(e)}
