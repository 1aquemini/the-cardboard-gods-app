import requests
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class YGOProDeckAPI:
    BASE_URL = "https://db.ygoprodeck.com/api/v7"
    
    @staticmethod
    def fetch_card_by_name(card_name):
        """Fetch card data from YGO ProDeck by name"""
        try:
            response = requests.get(
                f"{YGOProDeckAPI.BASE_URL}/cardinfo.php",
                params={'name': card_name},
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            
            if 'data' in data and len(data['data']) > 0:
                return data['data'][0]
            return None
        except requests.RequestException as e:
            logger.error(f"YGO ProDeck API error: {e}")
            return None
    
    @staticmethod
    def fetch_prices(card_name):
        """Fetch market prices from YGO ProDeck"""
        card_data = YGOProDeckAPI.fetch_card_by_name(card_name)
        if not card_data:
            return None
        
        prices = card_data.get('card_prices', [{}])[0]
        return {
            'source': 'ygoprodeck',
            'market_price': float(prices.get('tcgplayer_price') or 0),
            'lowest_listing': float(prices.get('ebay_price') or 0),
            'currency': 'USD',
            'recorded_at': datetime.utcnow().isoformat()
        }
    
    @staticmethod
    def search_cards(query):
        """Search for cards matching query"""
        try:
            response = requests.get(
                f"{YGOProDeckAPI.BASE_URL}/cardinfo.php",
                params={'fname': query},
                timeout=10
            )
            response.raise_for_status()
            data = response.json()
            return data.get('data', [])
        except requests.RequestException as e:
            logger.error(f"YGO ProDeck search error: {e}")
            return []

    @staticmethod
    def get_all_cards():
        """Fetch all cards (pagination handled by API)"""
        try:
            response = requests.get(
                f"{YGOProDeckAPI.BASE_URL}/cardinfo.php",
                timeout=30
            )
            response.raise_for_status()
            data = response.json()
            return data.get('data', [])
        except requests.RequestException as e:
            logger.error(f"YGO ProDeck fetch all error: {e}")
            return []
