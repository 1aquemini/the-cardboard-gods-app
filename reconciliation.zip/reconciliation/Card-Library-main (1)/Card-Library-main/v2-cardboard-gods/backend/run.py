import os
from app import create_app, db
from models import Card, Inventory, MarketPrice

app = create_app(os.getenv('FLASK_ENV', 'development'))

@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'Card': Card, 'Inventory': Inventory, 'MarketPrice': MarketPrice}

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run()
