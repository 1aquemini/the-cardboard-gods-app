import logging
from functools import wraps
from flask import jsonify, request
from app import db

logger = logging.getLogger(__name__)

class ValidationError(Exception):
    """Custom validation error"""
    def __init__(self, message, status_code=400):
        self.message = message
        self.status_code = status_code

class ResourceNotFound(Exception):
    """Resource not found error"""
    def __init__(self, resource_type, resource_id):
        self.message = f"{resource_type} '{resource_id}' not found"
        self.status_code = 404

class ResourceConflict(Exception):
    """Resource already exists error"""
    def __init__(self, resource_type, resource_id):
        self.message = f"{resource_type} '{resource_id}' already exists"
        self.status_code = 409

def handle_db_errors(func):
    """Decorator to handle database errors gracefully"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValidationError as e:
            logger.warning(f"Validation error: {e.message}")
            return jsonify({'error': e.message}), e.status_code
        except ResourceNotFound as e:
            logger.warning(f"Resource not found: {e.message}")
            return jsonify({'error': e.message}), e.status_code
        except ResourceConflict as e:
            logger.warning(f"Resource conflict: {e.message}")
            return jsonify({'error': e.message}), e.status_code
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}", exc_info=True)
            db.session.rollback()
            return jsonify({'error': 'Internal server error'}), 500
    return wrapper

def validate_required_fields(data, required_fields):
    """Validate that required fields are present in request data"""
    if not data:
        raise ValidationError('Request body cannot be empty')
    missing = [f for f in required_fields if f not in data]
    if missing:
        raise ValidationError(f'Missing required fields: {', '.join(missing)}')
    return True

def validate_card_condition(condition):
    """Validate card condition against allowed values"""
    valid_conditions = ['Gem Mint', 'Mint', 'Near Mint', 'Excellent', 'Very Good', 'Good', 'Fair', 'Poor']
    if condition not in valid_conditions:
        raise ValidationError(f'Invalid condition. Must be one of: {', '.join(valid_conditions)}')
    return True
