#!/bin/bash
# Health check script for monitoring

HOST="${1:-localhost:5000}"
MAX_RETRIES=3
RETRY_COUNT=0

echo "Checking health of $HOST..."

while [ $RETRY_COUNT -lt $MAX_RETRIES ]; do
    RESPONSE=$(curl -s -w "\n%{http_code}" http://$HOST/health)
    HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
    BODY=$(echo "$RESPONSE" | sed '$d')
    
    if [ "$HTTP_CODE" = "200" ]; then
        echo "✓ Health check passed"
        echo "$BODY" | jq .
        exit 0
    else
        echo "✗ Health check failed (HTTP $HTTP_CODE)"
        RETRY_COUNT=$((RETRY_COUNT + 1))
        if [ $RETRY_COUNT -lt $MAX_RETRIES ]; then
            echo "Retrying in 5 seconds..."
            sleep 5
        fi
    fi
done

echo "✗ Health check failed after $MAX_RETRIES attempts"
exit 1
