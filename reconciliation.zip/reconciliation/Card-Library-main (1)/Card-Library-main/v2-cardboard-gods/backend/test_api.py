import pytest
import sys
import os
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app import create_app, db
from models import Card, Inventory, MarketPrice

@pytest.fixture
def app():
    """Create application for testing"""
    app = create_app('testing')
    
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(app):
    """Test client"""
    return app.test_client()

@pytest.fixture
def sample_card():
    """Create sample card for testing"""
    return Card(
        card_id='test_001',
        name='Test Card',
        game='Yu-Gi-Oh!',
        card_type='Spell Card',
        rarity='Ultra Rare'
    )

def test_health_check(client):
    """Test health endpoint"""
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json['status'] == 'healthy'
    assert response.json['database'] == 'connected'

def test_get_cards_empty(client):
    """Test getting cards when database is empty"""
    response = client.get('/api/cards')
    assert response.status_code == 200
    assert response.json['total'] == 0
    assert response.json['data'] == []

def test_create_card(client):
    """Test creating a new card"""
    data = {
        'card_id': 'ygo_001',
        'name': 'Dark Magician',
        'game': 'Yu-Gi-Oh!',
        'rarity': 'Ultra Rare'
    }
    response = client.post('/api/cards', json=data)
    assert response.status_code == 201
    assert response.json['card_id'] == 'ygo_001'
    assert response.json['name'] == 'Dark Magician'

def test_create_card_missing_fields(client):
    """Test creating card with missing required fields"""
    data = {'card_id': 'ygo_001'}  # Missing name and game
    response = client.post('/api/cards', json=data)
    assert response.status_code == 400
    assert 'error' in response.json

def test_create_duplicate_card(client):
    """Test creating duplicate card returns 409"""
    data = {
        'card_id': 'ygo_001',
        'name': 'Dark Magician',
        'game': 'Yu-Gi-Oh!'
    }
    client.post('/api/cards', json=data)
    response = client.post('/api/cards', json=data)  # Try again
    assert response.status_code == 409

def test_search_cards(client):
    """Test card search functionality"""
    # Create test card
    data = {
        'card_id': 'ygo_001',
        'name': 'Dark Magician',
        'game': 'Yu-Gi-Oh!'
    }
    client.post('/api/cards', json=data)
    
    # Search
    response = client.get('/api/cards/search?q=Dark')
    assert response.status_code == 200
    assert len(response.json) > 0
    assert response.json[0]['name'] == 'Dark Magician'

def test_search_cards_query_too_short(client):
    """Test search with query < 2 characters"""
    response = client.get('/api/cards/search?q=D')
    assert response.status_code == 400
    assert 'error' in response.json

def test_add_inventory(client):
    """Test adding inventory item"""
    # Create card first
    card_data = {
        'card_id': 'ygo_001',
        'name': 'Dark Magician',
        'game': 'Yu-Gi-Oh!'
    }
    client.post('/api/cards', json=card_data)
    
    # Add inventory
    inv_data = {
        'card_id': 'ygo_001',
        'condition': 'Mint',
        'quantity': 2,
        'location': 'Binder A'
    }
    response = client.post('/api/inventory', json=inv_data)
    assert response.status_code == 201
    assert response.json['quantity'] == 2
    assert response.json['condition'] == 'Mint'

def test_add_inventory_invalid_condition(client):
    """Test adding inventory with invalid condition"""
    # Create card
    card_data = {
        'card_id': 'ygo_001',
        'name': 'Dark Magician',
        'game': 'Yu-Gi-Oh!'
    }
    client.post('/api/cards', json=card_data)
    
    # Try invalid condition
    inv_data = {
        'card_id': 'ygo_001',
        'condition': 'InvalidCondition',
        'quantity': 1
    }
    response = client.post('/api/inventory', json=inv_data)
    assert response.status_code == 400

def test_inventory_stats(client):
    """Test inventory statistics endpoint"""
    response = client.get('/api/inventory/stats/summary')
    assert response.status_code == 200
    assert 'total_line_items' in response.json
    assert 'total_cards' in response.json
    assert 'by_condition' in response.json
