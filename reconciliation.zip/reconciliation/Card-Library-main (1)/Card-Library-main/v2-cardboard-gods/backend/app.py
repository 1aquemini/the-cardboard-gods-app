import os
import logging
from datetime import datetime
from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from config import config
from utils.logger import setup_logging

db = SQLAlchemy()
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

logger = logging.getLogger(__name__)

def create_app(config_name=None):
    """Application factory pattern for Flask app creation"""
    if config_name is None:
        config_name = os.getenv('FLASK_ENV', 'development')
    
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Setup logging
    setup_logging(app)
    app.logger.info(f"Initializing Cardboard Gods API in {config_name} mode")
    
    # Initialize extensions
    db.init_app(app)
    CORS(app, resources={r"/api/*": {"origins": os.getenv('CORS_ORIGINS', '*').split(',')}})
    limiter.init_app(app)
    
    # Register blueprints
    from routes.cards import cards_bp
    from routes.inventory import inventory_bp
    from routes.prices import prices_bp
    from routes.health import health_bp
    
    app.register_blueprint(health_bp)
    app.register_blueprint(cards_bp, url_prefix='/api')
    app.register_blueprint(inventory_bp, url_prefix='/api')
    app.register_blueprint(prices_bp, url_prefix='/api')
    
    # Request logging middleware
    @app.before_request
    def log_request():
        app.logger.debug(f"{request.method} {request.path} - IP: {request.remote_addr}")
    
    @app.after_request
    def log_response(response):
        app.logger.debug(f"Response: {response.status_code}")
        return response
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({'error': 'Resource not found', 'status': 404}), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        app.logger.error(f"Internal error: {str(error)}", exc_info=True)
        db.session.rollback()
        return jsonify({'error': 'Internal server error', 'status': 500}), 500
    
    @app.errorhandler(429)
    def ratelimit_handler(e):
        app.logger.warning(f"Rate limit exceeded: {str(e)}")
        return jsonify({'error': 'Rate limit exceeded', 'message': str(e.description)}), 429
    
    # Health check endpoint
    @app.route('/health', methods=['GET'])
    def health():
        try:
            db.session.execute('SELECT 1')
            return jsonify({
                'status': 'healthy',
                'database': 'connected',
                'timestamp': datetime.utcnow().isoformat()
            }), 200
        except Exception as e:
            app.logger.error(f"Health check failed: {str(e)}")
            return jsonify({
                'status': 'unhealthy',
                'database': 'disconnected',
                'error': str(e)
            }), 503
    
    # Initialize database
    with app.app_context():
        db.create_all()
        app.logger.info('Database initialized')
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
