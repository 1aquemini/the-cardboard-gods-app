from app import db
from datetime import datetime

class Card(db.Model):
    __tablename__ = 'cards'
    
    card_id = db.Column(db.String(50), primary_key=True)
    name = db.Column(db.String(255), nullable=False, index=True)
    game = db.Column(db.String(50), default='Yu-Gi-Oh!', index=True)
    card_type = db.Column(db.String(50))
    attribute = db.Column(db.String(50))
    rarity = db.Column(db.String(50))
    description = db.Column(db.Text)
    set_name = db.Column(db.String(255), index=True)
    set_code = db.Column(db.String(20))
    card_number = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    inventory = db.relationship('Inventory', back_populates='card', cascade='all, delete-orphan')
    prices = db.relationship('MarketPrice', back_populates='card', cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'card_id': self.card_id,
            'name': self.name,
            'game': self.game,
            'card_type': self.card_type,
            'attribute': self.attribute,
            'rarity': self.rarity,
            'set_name': self.set_name,
            'set_code': self.set_code
        }
    
    def to_dict_detailed(self):
        data = self.to_dict()
        data['description'] = self.description
        data['card_number'] = self.card_number
        data['inventory_count'] = sum(i.quantity for i in self.inventory)
        data['current_prices'] = [p.to_dict() for p in self.prices]
        data['avg_price'] = self._calculate_avg_price()
        return data
    
    def _calculate_avg_price(self):
        prices = [p.market_price for p in self.prices if p.market_price]
        return sum(prices) / len(prices) if prices else None

class Inventory(db.Model):
    __tablename__ = 'inventory'
    
    sku = db.Column(db.Integer, primary_key=True, autoincrement=True)
    card_id = db.Column(db.String(50), db.ForeignKey('cards.card_id'), nullable=False, index=True)
    condition = db.Column(db.String(50), nullable=False)  # Gem Mint, Mint, Near Mint, Excellent, Very Good, Good, Fair, Poor
    language = db.Column(db.String(50), default='English')
    quantity = db.Column(db.Integer, default=1, nullable=False)
    cost_basis = db.Column(db.Float, default=0)
    location = db.Column(db.String(100), default='Unknown')
    is_listed = db.Column(db.Boolean, default=False, index=True)
    photo_ref = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    card = db.relationship('Card', back_populates='inventory')
    
    def to_dict(self):
        return {
            'sku': self.sku,
            'card_id': self.card_id,
            'card_name': self.card.name if self.card else 'Unknown',
            'condition': self.condition,
            'language': self.language,
            'quantity': self.quantity,
            'cost_basis': self.cost_basis,
            'location': self.location,
            'is_listed': self.is_listed,
            'photo_ref': self.photo_ref,
            'notes': self.notes,
            'last_updated': self.last_updated.isoformat()
        }

class MarketPrice(db.Model):
    __tablename__ = 'market_prices'
    
    id = db.Column(db.Integer, primary_key=True)
    card_id = db.Column(db.String(50), db.ForeignKey('cards.card_id'), nullable=False, index=True)
    source = db.Column(db.String(50), nullable=False)  # 'ygoprodeck', 'ebay', 'tcgplayer'
    market_price = db.Column(db.Float)
    lowest_listing = db.Column(db.Float)
    highest_listing = db.Column(db.Float)
    num_listings = db.Column(db.Integer)
    currency = db.Column(db.String(10), default='USD')
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Relationships
    card = db.relationship('Card', back_populates='prices')
    
    def to_dict(self):
        return {
            'source': self.source,
            'market_price': self.market_price,
            'lowest_listing': self.lowest_listing,
            'highest_listing': self.highest_listing,
            'num_listings': self.num_listings,
            'currency': self.currency,
            'recorded_at': self.recorded_at.isoformat()
        }
