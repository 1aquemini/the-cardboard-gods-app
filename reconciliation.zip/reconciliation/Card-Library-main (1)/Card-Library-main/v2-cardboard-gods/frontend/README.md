# Frontend scaffolding for Cardboard Gods
# Framework: React (you can swap to Vue/Svelte if preferred)

Starts with:
- Vite for fast dev + build
- TypeScript for type safety
- Tailwind CSS for styling
- Axios for API calls
- React Query for state management

## Quick Start

```bash
cd v2-cardboard-gods/frontend
npm install
npm run dev
```

Frontend will be available at `http://localhost:5173`

## Project Structure

```
frontend/
├── src/
│   ├── components/       # Reusable UI components
│   │   ├── CardList.tsx
│   │   ├── CardDetail.tsx
│   │   ├── InventoryForm.tsx
│   │   └── PriceChart.tsx
│   ├── pages/            # Page components
│   │   ├── HomePage.tsx
│   │   ├── InventoryPage.tsx
│   │   ├── CardDetailPage.tsx
│   │   └── ScanPage.tsx
│   ├── hooks/            # Custom React hooks
│   │   ├── useCards.ts
│   │   ├── useInventory.ts
│   │   └── usePrices.ts
│   ├── services/         # API client
│   │   ├── api.ts
│   │   ├── cardService.ts
│   │   └── inventoryService.ts
│   ├── types/            # TypeScript types
│   │   └── index.ts
│   ├── App.tsx
│   └── main.tsx
├── public/               # Static assets
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

## Key Features to Build

- [ ] Card catalog with search/filter
- [ ] Inventory management (CRUD)
- [ ] Price tracking dashboard
- [ ] Mobile camera integration for card scanning
- [ ] Real-time price updates via WebSocket
- [ ] eBay listing sync
- [ ] Export to CSV
- [ ] User authentication
- [ ] Mobile-responsive design

## Environment Setup

Create `.env.local`:

```
VITE_API_URL=http://localhost:5000/api
VITE_API_TIMEOUT=10000
```

## Build & Deploy

```bash
# Production build
npm run build

# Preview production build
npm run preview
```

Deploy to Vercel or Netlify by connecting this repo.
