# Cardboard Gods Backend Setup

## Quick Start with Docker

```bash
docker-compose up -d
```

This will start:
- PostgreSQL database on `localhost:5432`
- Flask API server on `localhost:5000`

## Manual Setup

### 1. Install Dependencies

```bash
cd v2-cardboard-gods/backend
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your settings:
```
DATABASE_URL=postgresql://user:password@localhost:5432/cardboard_gods
FLASK_ENV=development
SECRET_KEY=your-secret-key
EBAY_OAUTH_TOKEN=your-token-here
```

### 3. Initialize Database

```bash
python run.py
```

This will:
- Connect to PostgreSQL
- Create all tables
- Start the development server

### 4. Load Data

Place your CSV/XLSX files in `data/raw/` then run:

```bash
python src/etl/data_merger.py
```

## API Endpoints

### Health Check
- `GET /health` — Server status
- `GET /api/version` — API version info

### Cards
- `GET /api/cards` — List all cards (paginated)
- `GET /api/cards?game=Yu-Gi-Oh!&per_page=100` — Filter by game
- `GET /api/cards/<card_id>` — Get card details
- `GET /api/cards/search?q=Dark+Magician` — Search cards
- `POST /api/cards` — Create new card
- `PUT /api/cards/<card_id>` — Update card
- `DELETE /api/cards/<card_id>` — Delete card

### Inventory
- `GET /api/inventory` — List inventory (paginated)
- `GET /api/inventory?condition=Mint&is_listed=true` — Filter inventory
- `GET /api/inventory/<sku>` — Get item details
- `POST /api/inventory` — Add new item
- `PUT /api/inventory/<sku>` — Update item
- `DELETE /api/inventory/<sku>` — Delete item
- `GET /api/inventory/stats/summary` — Inventory statistics

### Pricing
- `GET /api/prices/<card_id>` — Get current prices (all sources)
- `GET /api/prices/source/ygoprodeck` — Get prices from specific source
- `GET /api/prices/history/<card_id>` — Get 30-day price history
- `GET /api/prices/outdated` — Cards needing price refresh
- `POST /api/prices` — Add/update price

## Testing

### Health Check
```bash
curl http://localhost:5000/health
```

### Add a Card
```bash
curl -X POST http://localhost:5000/api/cards \
  -H "Content-Type: application/json" \
  -d '{
    "card_id": "ygo_001",
    "name": "Dark Magician",
    "game": "Yu-Gi-Oh!",
    "card_type": "Spell Card",
    "rarity": "Ultra Rare"
  }'
```

### Add Inventory
```bash
curl -X POST http://localhost:5000/api/inventory \
  -H "Content-Type: application/json" \
  -d '{
    "card_id": "ygo_001",
    "condition": "Mint",
    "quantity": 1,
    "location": "Shelf A"
  }'
```

### Get Inventory Stats
```bash
curl http://localhost:5000/api/inventory/stats/summary
```

## Production Deployment

### Environment Variables

Set these before deploying:

```bash
export FLASK_ENV=production
export DATABASE_URL=postgresql://user:password@hostname:5432/cardboard_gods
export SECRET_KEY=your-very-secure-key-here
export EBAY_OAUTH_TOKEN=your-token
export CORS_ORIGINS=https://yourdomain.com
```

### Run with Gunicorn

```bash
gunicorn --bind 0.0.0.0:5000 --workers 4 --timeout 60 run:app
```

### Recommended Hosting

- **Database**: Neon.tech (free PostgreSQL)
- **API**: Railway.app, Heroku, or Fly.io
- **Frontend**: Vercel or Netlify

## Troubleshooting

**Database connection error:**
```bash
# Check DATABASE_URL is correct
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL -c "SELECT 1"
```

**Port already in use:**
```bash
# Kill existing process
lsof -i :5000
kill -9 <PID>
```

**eBay API not working:**
- Verify EBAY_OAUTH_TOKEN is set
- Check token hasn't expired (eBay tokens expire after 24 hours)
- Generate new token at developer.ebay.com

## Next Steps

1. ✅ Backend API running
2. ⏳ Frontend scaffolding (React/Vue/Svelte)
3. ⏳ Mobile app deployment
4. ⏳ OCR card scanning
5. ⏳ User authentication
