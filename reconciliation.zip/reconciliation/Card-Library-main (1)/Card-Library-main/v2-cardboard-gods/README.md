# Cardboard Gods v2 - Trading Card Inventory Management

**Production-ready web app for managing and valuing trading card collections.**

## Quick Start

```bash
git clone https://github.com/1aquemini/Card-Library.git
cd Card-Library
docker-compose up -d
```

API: http://localhost:5000

## What's Included

- Flask REST API with CRUD operations
- PostgreSQL database
- React frontend
- YGO ProDeck price integration
- ETL pipeline for data imports
- Docker containerization

## Setup

See [Backend Setup](v2-cardboard-gods/SETUP.md) and [Frontend README](v2-cardboard-gods/frontend/README.md)

## API Endpoints

**Cards:** GET /api/cards, POST /api/cards, PUT /api/cards/{id}, DELETE /api/cards/{id}
**Inventory:** GET /api/inventory, POST /api/inventory, PUT /api/inventory/{sku}, DELETE /api/inventory/{sku}
**Pricing:** GET /api/prices/{card_id}, GET /api/prices/history/{card_id}

## License

MIT
