# Database Schema Reference

Cards, Inventory, and Market Prices tables with relationships.
