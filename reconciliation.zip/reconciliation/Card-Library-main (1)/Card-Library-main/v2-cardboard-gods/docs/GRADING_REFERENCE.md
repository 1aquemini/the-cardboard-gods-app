# Card Grading Reference

Standard condition grades:

- Gem Mint (10) - Perfect
- Mint (9) - Excellent
- Near Mint (8) - Light wear
- Excellent (7) - Moderate wear
- Very Good (6) - Heavy wear
- Good (5) - Very heavy wear
- Fair (3) - Major damage
- Poor (1) - Severe damage
