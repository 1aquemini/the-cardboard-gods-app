import streamlit as st
import pandas as pd
import glob
import os

# App Configuration
st.set_page_config(page_title="The Cardboard Gods", page_icon="🃏", layout="centered")
st.title("The Cardboard Gods Inventory")

# Load and process your raw files directly from the repo
@st.cache_data
def load_inventory():
    all_data = []
    # Pointing to the raw data directory
    search_pattern = os.path.join(os.path.dirname(__file__), '../data/raw/*.[cx][sl]*[vxs]*')
    files = glob.glob(search_pattern)
    
    for file in files:
        try:
            df = pd.read_csv(file) if file.endswith('.csv') else pd.read_excel(file, engine='openpyxl')
            # Normalize headers
            df.columns = [str(col).strip().lower().replace(' ', '_') for col in df.columns]
            all_data.append(df)
        except Exception:
            pass
            
    if all_data:
        combined_df = pd.concat(all_data, ignore_index=True)
        # Drop empty rows to keep the mobile view clean
        combined_df.dropna(how='all', inplace=True)
        return combined_df
    return pd.DataFrame()

df = load_inventory()

# Mobile UI
if df.empty:
    st.warning("No data found! Ensure your CSV/XLSX files are in data/raw/ and pushed to GitHub.")
else:
    search_query = st.text_input("🔍 Search for a card (e.g., Dark Magician):")
    
    if search_query:
        # Filter dataframe across all columns based on the search query
        mask = df.astype(str).apply(lambda x: x.str.contains(search_query, case=False, na=False)).any(axis=1)
        results = df[mask]
        st.success(f"Found {len(results)} results:")
        st.dataframe(results, use_container_width=True)
    else:
        st.caption(f"Total Inventory: {len(df)} records")
        st.dataframe(df, use_container_width=True)