# The Cardboard Gods

Inventory management and automated eBay listing engine for Yu-Gi-Oh! cards.

## Setup
1. Place raw CSV/XLSX files in `data/raw/`
2. Run `pip install -r requirements.txt`
3. Configure `CLOSURE_WORKBOOK.csv` items.
4. Run `python src/etl/data_merger.py` to build the database.
