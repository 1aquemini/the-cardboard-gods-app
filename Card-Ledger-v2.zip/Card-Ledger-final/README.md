# Card Ledger v2

## Install on iPhone
1. Push this folder to GitHub.
2. Enable GitHub Pages.
3. Open the Pages URL in Safari.
4. Tap Share → Add to Home Screen.
5. Launch Card Ledger.
6. Tap Start Session and allow camera access.

Data is stored locally. Export CSV for backups.
